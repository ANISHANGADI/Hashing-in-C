/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define HZ 3
struct employee
{
    int empno;
    float sal;
    char nm[20];
};
typedef struct employee EMP;
struct hashtable
{
    int key;
    long int addr;
};
typedef struct hashtable ht;
void insert(ht *,int );
void search(ht *,int );
void display(ht *,int );
FILE *fp;
int main()
{   
    fp=fopen("data","w+");
    ht h[HZ];
    int n,ch;
    for(n=0;n<HZ;n++)
    h[n].key=-1;
    
    for(;;)
    {
        printf("1:insert\n2:search\n3:display\n4:exit\n");
        printf("Enter the choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1 : printf("Enter the number of employee\n");
                     scanf("%d",&n);
                     insert(h,n); break;
            case 2 : search(h,n); break;
            case 3 : display(h,n); break;
            default : exit(0);
        }
    }
}

int hashval(int num)
{
    int key;
    key=num%HZ;
    return key;
}

void insert(ht *h,int n)
{
    EMP a;
    int flag=0,hindex,countindex;
    int i;
    for(i=0;i<n;i++,flag=0)
    {
        printf("Enter the employee details\n");
        scanf("%d%f%s",&(a.empno),&(a.sal),a.nm);
        hindex=hashval(a.empno);
        countindex=hindex;
        while(h[hindex].key!=-1)
        {
            hindex=(hindex+1)%HZ;
            flag=1;
            if(hindex==countindex)
            {
                printf("No further elements can be entered\n");
                return;
            }
            
        }
        h[hindex].key=a.empno;
        fseek(fp,0,SEEK_END);
        h[hindex].addr=ftell(fp);
        fprintf(fp,"%d %f %s\n",(a.empno),(a.sal),a.nm);
        if(flag)
        printf("Linear probing used\n");
    }
}

void search(ht *h,int n)
{
     EMP a;
    int flag=0,hindex,countindex;
    int i;
    printf("Enter the employee no\n");
    scanf("%d",&(a.empno));
    hindex=hashval(a.empno);
    countindex=hindex;
    while(h[hindex].key!=a.empno)
    {
         hindex=(hindex+1)%HZ;
         if(hindex==countindex)
         {
             printf("Unsuccessful search\n");
             return;
         }
         
    }
    printf("Search successful\n");
    fseek(fp,h[hindex].addr,SEEK_SET);
    fscanf(fp,"%d%f%s",&(a.empno),&(a.sal),a.nm);
    printf("The employee details are %d %f %s\n",(a.empno),(a.sal),a.nm);
}
void display(ht *h,int n)
{
    EMP a;
    int i;
    for(i=0;i<HZ;i++)
    {
        if(h[i].key!=-1)
        {
            printf("The secondary storage details are %d %ld ",h[i].key,h[i].addr);
            fseek(fp,h[i].addr,SEEK_SET);
            fscanf(fp,"%d%f%s",&(a.empno),&(a.sal),a.nm);
            printf("The employee details are %d %f %s\n",(a.empno),(a.sal),a.nm);
        }
    }
}
